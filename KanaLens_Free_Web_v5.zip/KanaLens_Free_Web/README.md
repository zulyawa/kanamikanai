# KanaLens V5（静态网页修正版）

## 本次修复
- 修正 Kuroshiro Browser 初始化参数：GitHub Pages 直接托管静态 HTML，没有构建步骤，也没有把 npm 包内的 `dist/dict` 复制到站点根目录，因此不能把 `IS_PROD` 设为 `true`。V5 改为 `false`，使用包/CDN 对应的词典路径。
- 将智能注音状态显示放到输入区域下方，不再与 OCR 状态共用一个提示栏。
- 智能词典失败时明确显示错误原因，并退回内置常见词词典。

## 部署到 GitHub Pages
1. 解压 ZIP。
2. 在 GitHub 仓库 `zulyawa/kanasile` 中，进入 `Add file` → `Upload files`。
3. 上传本目录中的 `index.html` 和 `README.md`，覆盖仓库根目录同名文件。
4. 点击 `Commit changes` 提交到 `main`。
5. 等待 GitHub Pages 更新后，刷新 `https://zulyawa.github.io/kanasile/`。

## 测试
先输入：
- `今日` → `きょう`
- `学校` → `がっこう`
- `私は日本語を勉強しています。` → `わたしはにほんごをべんきょうしています。`

首次使用需要网络加载 Kuroshiro 模块和日语词典。若转换状态提示智能词典加载失败，请把该提示的完整错误文字或浏览器控制台截图发回，以便继续定位 CDN/词典网络问题。

## 限制
本工具提供日语假名注音和罗马音，不等同于中文翻译。人名、地名、多音词可能需要人工核对。OCR 首次加载日语模型也需要网络。
